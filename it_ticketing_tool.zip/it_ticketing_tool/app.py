from flask import Flask, render_template, request, redirect, url_for, flash
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime

# Initialize the Flask application
app = Flask(__name__)
# Set a secret key for Flash messages (required for security)
app.secret_key = 'your_super_secret_key' # IMPORTANT: In a real app, use an environment variable!

# --- Firebase Firestore Configuration ---
# IMPORTANT: Replace 'path/to/your/serviceAccountKey.json' with the actual path
# to the service account key file you download from Firebase.
# KEEP THIS FILE SECURE AND OUT OF VERSION CONTROL (e.g., .gitignore) IN PRODUCTION!
SERVICE_ACCOUNT_KEY_PATH = 'serviceAccountKey.json'

# Initialize Firebase Admin SDK
try:
    # Check if Firebase app is already initialized to avoid re-initialization errors
    if not firebase_admin._apps:
        cred = credentials.Certificate(SERVICE_ACCOUNT_KEY_PATH)
        firebase_admin.initialize_app(cred)
    db = firestore.client() # Get a Firestore client
    tickets_collection = db.collection('tickets') # Reference to your 'tickets' collection
    print("Connected to Firebase Firestore successfully!")
    db_connected = True
except Exception as e:
    print(f"Error connecting to Firebase Firestore: {e}")
    db_connected = False
    # In a production app, you'd want more robust error handling here.

@app.before_request
def check_db_connection():
    """
    Ensure database connection is active before processing requests.
    If not connected, flash a message and prevent further operations.
    """
    global db_connected # Use global to refer to the flag set during init
    if not db_connected:
        flash("Database connection not established. Please check server logs and Firebase setup.", 'error')
        # You might consider redirecting to a specific error page here
        # For now, we'll let individual routes handle the return if db_connected is False

@app.route('/')
def index():
    """
    Renders the homepage, displaying all existing tickets from Firestore.
    """
    if not db_connected:
        return render_template('index.html', tickets=[]) # Render with no tickets if DB is down

    try:
        # Fetch all tickets, ordered by creation_at timestamp in descending order
        # orderBy('created_at', direction=firestore.Query.DESCENDING)
        tickets_stream = tickets_collection.order_by('created_at', direction=firestore.Query.DESCENDING).stream()
        tickets = []
        for doc in tickets_stream:
            ticket_data = doc.to_dict()
            ticket_data['id'] = doc.id # Get the document ID for the ticket detail page
            # Convert datetime objects in comments for display if they exist
            if 'comments' in ticket_data and isinstance(ticket_data['comments'], list):
                for comment in ticket_data['comments']:
                    if 'timestamp' in comment and isinstance(comment['timestamp'], datetime):
                        comment['timestamp'] = comment['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
            tickets.append(ticket_data)

        return render_template('index.html', tickets=tickets)
    except Exception as e:
        flash(f"Error fetching tickets: {e}", 'error')
        print(f"Error in index route: {e}")
        return render_template('index.html', tickets=[])

@app.route('/create', methods=('GET', 'POST'))
def create():
    """
    Handles the creation of new tickets in Firestore.
    """
    if not db_connected:
        flash("Database is not connected. Cannot create ticket.", 'error')
        return redirect(url_for('index'))

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        reporter = request.form['reporter']
        status = request.form.get('status', 'Open')
        priority = request.form.get('priority', 'Low')

        if not title or not description or not reporter:
            flash('Title, Description, and Reporter are required!', 'error')
        else:
            try:
                new_ticket_data = {
                    "title": title,
                    "description": description,
                    "status": status,
                    "priority": priority,
                    "reporter": reporter,
                    "comments": [], # Comments will be an array of sub-documents
                    "created_at": datetime.now(),
                    "updated_at": datetime.now()
                }
                tickets_collection.add(new_ticket_data) # Add a new document to the collection
                flash('Ticket created successfully!', 'success')
                return redirect(url_for('index'))
            except Exception as e:
                flash(f"Error creating ticket: {e}", 'error')
                print(f"Error creating ticket: {e}")

    return render_template('create.html')

@app.route('/ticket/<ticket_id>')
def ticket(ticket_id):
    """
    Displays the details of a single ticket from Firestore.
    """
    if not db_connected:
        flash("Database is not connected. Cannot view ticket details.", 'error')
        return redirect(url_for('index'))

    try:
        ticket_doc = tickets_collection.document(ticket_id).get() # Get document by ID
        if not ticket_doc.exists:
            flash('Ticket not found!', 'error')
            return redirect(url_for('index'))

        ticket_data = ticket_doc.to_dict()
        ticket_data['id'] = ticket_doc.id # Add ID to data for template

        # Convert datetime objects in comments to string for display
        comments = ticket_data.get('comments', [])
        for comment in comments:
            if 'timestamp' in comment and isinstance(comment['timestamp'], datetime):
                comment['timestamp'] = comment['timestamp'].strftime('%Y-%m-%d %H:%M:%S')

        return render_template('ticket.html', ticket=ticket_data, comments=comments)
    except Exception as e:
        flash(f"Error retrieving ticket: {e}", 'error')
        print(f"Error in ticket route: {e}")
        return redirect(url_for('index'))

@app.route('/ticket/<ticket_id>/update', methods=('POST',))
def update_ticket(ticket_id):
    """
    Handles updating the status and priority of an existing ticket in Firestore.
    """
    if not db_connected:
        flash("Database is not connected. Cannot update ticket.", 'error')
        return redirect(url_for('ticket', ticket_id=ticket_id))

    if request.method == 'POST':
        new_status = request.form.get('status')
        new_priority = request.form.get('priority')

        try:
            tickets_collection.document(ticket_id).update({
                "status": new_status,
                "priority": new_priority,
                "updated_at": datetime.now()
            })
            flash('Ticket updated successfully!', 'success')
        except Exception as e:
            flash(f'Error updating ticket: {e}', 'error')
            print(f"Error updating ticket: {e}")

    return redirect(url_for('ticket', ticket_id=ticket_id))

@app.route('/ticket/<ticket_id>/add_comment', methods=('POST',))
def add_comment(ticket_id):
    """
    Handles adding comments to an existing ticket in Firestore.
    Comments are appended to an array within the ticket document.
    """
    if not db_connected:
        flash("Database is not connected. Cannot add comment.", 'error')
        return redirect(url_for('ticket', ticket_id=ticket_id))

    if request.method == 'POST':
        comment_text = request.form['comment_text']
        commenter_name = request.form.get('commenter_name', 'Anonymous')
        current_time = datetime.now() # Store as datetime object

        if not comment_text:
            flash('Comment cannot be empty!', 'error')
        else:
            new_comment = {
                'text': comment_text,
                'commenter': commenter_name,
                'timestamp': current_time # Firestore handles datetime objects directly
            }
            try:
                # Use FieldValue.array_union to atomically add a new comment to the 'comments' array
                tickets_collection.document(ticket_id).update({
                    "comments": firestore.ArrayUnion([new_comment]),
                    "updated_at": datetime.now()
                })
                flash('Comment added successfully!', 'success')
            except Exception as e:
                flash(f'Error adding comment: {e}', 'error')
                print(f"Error adding comment: {e}")

    return redirect(url_for('ticket', ticket_id=ticket_id))


# Entry point for running the Flask app
if __name__ == '__main__':
    # This will run the Flask development server
    app.run(debug=True)
